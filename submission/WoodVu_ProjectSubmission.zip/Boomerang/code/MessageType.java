
public enum MessageType
{
	TX, COVER, POISON
}
